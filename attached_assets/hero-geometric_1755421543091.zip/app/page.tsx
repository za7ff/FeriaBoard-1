"use client"

import HeroGeometric from "../components/kokonutui/hero-geometric"

export default function SyntheticV0PageForDeployment() {
  return <HeroGeometric />
}