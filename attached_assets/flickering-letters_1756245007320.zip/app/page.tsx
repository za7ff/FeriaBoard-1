import RainingLetters from "../components/RainingLetters"

export default function Home() {
  return (
    <main className="min-h-screen">
      <RainingLetters />
    </main>
  )
}
